print("Hello World")
a1 = 10
a2 = 10.5
a3 = 'KLU'
a4 = True
a5=[1,2,3,4,5]
a6=(1,'Varshi',2.3)
a7={1,32,4,"Asia"}
a8=[7,8,9,10]
a9=(3,'Vishi',9.8)
a10={20,45,3,"Antarctica"}
a11=a5+a8
a12=a6+a8
a13=a7+a10
print(a11)
print(a12)
print(a13)