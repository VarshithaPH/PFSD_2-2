a12 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
avg = sum(a12) / len(a12)
print(avg)
