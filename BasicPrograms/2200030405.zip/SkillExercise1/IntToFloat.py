x=123.12
x=float(x)
print(x)